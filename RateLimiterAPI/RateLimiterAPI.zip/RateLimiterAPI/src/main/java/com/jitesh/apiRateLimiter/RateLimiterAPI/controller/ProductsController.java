package com.jitesh.apiRateLimiter.RateLimiterAPI.controller;


import org.springframework.stereotype.Controller;

@Controller
public class ProductsController {
}
