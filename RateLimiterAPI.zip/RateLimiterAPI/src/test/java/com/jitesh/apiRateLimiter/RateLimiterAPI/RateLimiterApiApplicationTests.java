package com.jitesh.apiRateLimiter.RateLimiterAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RateLimiterApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
